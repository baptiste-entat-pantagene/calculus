
#ifndef BASICOPPERATION_H
#define BASICOPPERATION_H


#include <list>
#include <string>
#include <vector>

#include "atomType.h"

namespace calculus
{

    static void coNormaliseVector(std::vector<atom_t> left, std::vector<atom_t> right)
    {
        const size_t size_left = size_vector_atom_single(left);
        const size_t size_right = size_vector_atom_single(right);
        const size_t diff = std::abs(size_left - size_right);

        if (size_left < size_right)
        {
            
        }
        else if (size_left > size_right)
        {

        }
        else
        {
            return;
        }



    }

    static std::list<atom_t> add(const std::list<atom_t> &left, const std::list<atom_t> &right)
    {
        size_t size_left = size_list_atom_single(left);
        size_t size_right = size_list_atom_single(right);
        size_t size_max;
        const std::list<atom_t>* max;
        size_t size_min;
        const std::list<atom_t>* min;

        if (size_left >= size_right)
        {
            size_max = size_left;
            max = &left;
            size_min = size_right;
            min = &right;
        }
        else
        {
            size_max = size_right;
            max = &right;
            size_min = size_left;
            min = &left;
        }

        auto* result = new std::list<atom_t>();
        size_t held = 0;
        auto it_max = max->end();
        auto it_min = min->end();
        for (size_t i = 0; i < size_min - 1; ++i)
        {
            atom_t r_atom = {};
            const atom_t* max_atom = it_max.operator->();
            const atom_t* min_atom = it_min.operator->();

            held+= max_atom->getDown();
            held+= min_atom->getDown();



        }




    }

}

#endif //BASICOPPERATION_H
